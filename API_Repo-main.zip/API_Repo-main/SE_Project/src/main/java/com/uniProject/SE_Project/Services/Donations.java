package com.uniProject.SE_Project.Services;
import java.util.*;
public class Donations implements Services {
     
	Donations(){}

	@Override
	public Boolean acceptCash() {
		return false;
	}
}

