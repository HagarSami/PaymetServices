package com.uniProject.SE_Project.Services;
import java.util.*;
public class LandlineServices  implements Services {
    
	LandlineServices(){}


	@Override
	public Boolean acceptCash() {
		return true;
	}
}