package com.uniProject.SE_Project.Services;
public interface Services {
    public Boolean acceptCash();
	
}
