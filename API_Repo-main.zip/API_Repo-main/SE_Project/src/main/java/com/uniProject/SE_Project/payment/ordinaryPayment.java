package com.uniProject.SE_Project.payment;
import com.uniProject.SE_Project.user.UsersModel;
import org.springframework.stereotype.Service;


public interface ordinaryPayment {

	String Pay(double amount);
}
