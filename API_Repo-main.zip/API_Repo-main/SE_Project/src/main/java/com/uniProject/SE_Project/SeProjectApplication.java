package com.uniProject.SE_Project;
import com.uniProject.SE_Project.payment.ordinaryPayment;
import com.uniProject.SE_Project.payment.PaymentController;
//import com.uniProject.SE_Project.cost.Discount;
import com.uniProject.SE_Project.cost.ControllerDiscount;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeProjectApplication.class, args);
	}

	
}
